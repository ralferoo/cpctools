﻿Module Module1

    Private Declare Function sndPlaySound Lib "winmm.dll" Alias "sndPlaySoundA" (ByVal lpszSoundName As String, ByVal uFlags As Integer) As Integer

    Private Const sndAsync As Integer = &H1
    Private Const sndSync As Integer = &H0
    Private Const sndLoop As Integer = &H8
    Private Const sndNoStop As Integer = &H10


    Sub Main()
        If Command() = "" Then
            Console.WriteLine("Syntax: sounder.exe filename.wav")
            Console.WriteLine("")
            Console.WriteLine("http://www.elifulkerson.com")
        Else

            sndPlaySound(System.IO.Path.GetFullPath(Command()), sndSync)
        End If

    End Sub

End Module
